# CodeAlpha Artificial Intelligence Internship — Complete Tasks

This repository contains complete implementations for all 4 AI tasks from the CodeAlpha assignment:

1. Language Translation Tool
2. FAQ Chatbot
3. Music Generation with AI
4. Object Detection and Tracking

> The internship instructions require any 2 or 3 tasks, but all 4 are included here.

## Recommended Python
Python 3.10 or 3.11.

## Folder structure

- `task1_translation/` — Streamlit UI + Google Cloud Translation API
- `task2_faq_chatbot/` — TF-IDF + cosine similarity FAQ chatbot
- `task3_music_generation/` — LSTM MIDI music generator
- `task4_object_tracking/` — YOLO object detection + ByteTrack tracking

## Quick setup

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

Each task has its own README with exact commands.

## GitHub

Suggested repository name:

`CodeAlpha_ProjectName`

Do not upload API keys. Use environment variables or a `.env` file excluded by `.gitignore`.
