# CodeAlpha Submission Checklist

For each completed project:

- [ ] Source code runs successfully
- [ ] README contains setup and run instructions
- [ ] GitHub repository name follows `CodeAlpha_ProjectName`
- [ ] No API keys/passwords are committed
- [ ] Add screenshots of the working application
- [ ] Record a short video explaining the project
- [ ] Upload the video to LinkedIn with the GitHub repository link
- [ ] Tag `@CodeAlpha`
- [ ] Submit the completed task through the official submission form

## Suggested GitHub structure

You can keep all four folders in one repository, or create separate repositories:

- `CodeAlpha_LanguageTranslation`
- `CodeAlpha_FAQChatbot`
- `CodeAlpha_MusicGeneration`
- `CodeAlpha_ObjectTracking`
